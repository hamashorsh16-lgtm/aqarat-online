// زانیارییەکانی Supabase لێرە دابنێ.
// URL و anon/publishable key بۆ بەکارهێنانی لە براوزەر دروستن.
// NEVER لە هیچ کاتێک service_role key لەم فایلەدا دانەنێ.
window.AQARAT_CONFIG = {
  url: "PASTE_SUPABASE_PROJECT_URL_HERE",
  anonKey: "PASTE_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE",
  workspaceId: "7d6c5d4e-3f2a-4b1c-9d8e-7f6a5b4c3d2e"
};
