-- Supabase SQL Editor: ئەم فایلە بە تەواوی جێبەجێ بکە.
create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key,
  name text not null default 'سیستەمی عەقارات',
  created_at timestamptz not null default now()
);

insert into public.workspaces (id, name)
values ('7d6c5d4e-3f2a-4b1c-9d8e-7f6a5b4c3d2e', 'سیستەمی عەقارات')
on conflict (id) do nothing;

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'editor' check (role in ('admin','editor','viewer')),
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  property_type text not null,
  deal_type text not null check (deal_type in ('فرۆشتن','کرێ')),
  status text not null default 'بەردەست',
  address text not null,
  asking_price numeric(14,2) not null default 0 check (asking_price >= 0),
  final_price numeric(14,2) check (final_price is null or final_price >= 0),
  area_sqm numeric(12,2) check (area_sqm is null or area_sqm >= 0),
  owner_name text,
  owner_phone text,
  customer_name text,
  customer_phone text,
  commission_percent numeric(5,2) check (commission_percent is null or commission_percent between 0 and 100),
  staff_name text,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists properties_workspace_created_idx on public.properties(workspace_id, created_at desc);
create index if not exists members_user_idx on public.workspace_members(user_id);

create or replace function public.is_workspace_member(target_workspace uuid)
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.workspace_members m
    where m.workspace_id = target_workspace and m.user_id = auth.uid()
  );
$$;

create or replace function public.has_workspace_role(target_workspace uuid, allowed_roles text[])
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.workspace_members m
    where m.workspace_id = target_workspace and m.user_id = auth.uid() and m.role = any(allowed_roles)
  );
$$;

revoke all on function public.is_workspace_member(uuid) from public;
revoke all on function public.has_workspace_role(uuid,text[]) from public;
grant execute on function public.is_workspace_member(uuid) to authenticated;
grant execute on function public.has_workspace_role(uuid,text[]) to authenticated;

alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.properties enable row level security;

drop policy if exists "members can view their workspace" on public.workspaces;
create policy "members can view their workspace" on public.workspaces
for select to authenticated using (public.is_workspace_member(id));

drop policy if exists "members can see own workspace members" on public.workspace_members;
create policy "members can see own workspace members" on public.workspace_members
for select to authenticated using (public.is_workspace_member(workspace_id));

drop policy if exists "admins add workspace members" on public.workspace_members;
create policy "admins add workspace members" on public.workspace_members
for insert to authenticated with check (public.has_workspace_role(workspace_id, array['admin']));

drop policy if exists "admins change workspace members" on public.workspace_members;
create policy "admins change workspace members" on public.workspace_members
for update to authenticated using (public.has_workspace_role(workspace_id, array['admin']))
with check (public.has_workspace_role(workspace_id, array['admin']));

drop policy if exists "admins remove workspace members" on public.workspace_members;
create policy "admins remove workspace members" on public.workspace_members
for delete to authenticated using (public.has_workspace_role(workspace_id, array['admin']));

drop policy if exists "members can read properties" on public.properties;
create policy "members can read properties" on public.properties
for select to authenticated using (public.is_workspace_member(workspace_id));

drop policy if exists "editors and admins add properties" on public.properties;
create policy "editors and admins add properties" on public.properties
for insert to authenticated with check (
  public.has_workspace_role(workspace_id, array['admin','editor'])
  and (created_by is null or created_by = auth.uid())
);

drop policy if exists "editors and admins update properties" on public.properties;
create policy "editors and admins update properties" on public.properties
for update to authenticated using (public.has_workspace_role(workspace_id, array['admin','editor']))
with check (public.has_workspace_role(workspace_id, array['admin','editor']));

drop policy if exists "admins delete properties" on public.properties;
create policy "admins delete properties" on public.properties
for delete to authenticated using (public.has_workspace_role(workspace_id, array['admin']));

-- پاراستنی created_at و workspace_id لە دەستکاریی ناخوازییەکان
create or replace function public.protect_property_fields()
returns trigger language plpgsql set search_path = public
as $$
begin
  if tg_op = 'UPDATE' then
    new.workspace_id := old.workspace_id;
    new.created_by := old.created_by;
    new.created_at := old.created_at;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists properties_protect_fields on public.properties;
create trigger properties_protect_fields before update on public.properties
for each row execute function public.protect_property_fields();

-- هەنگاوی گرنگی دوای دروستکردنی یەکەم هەژمار:
-- لە Supabase > SQL Editor، ئیمەیڵی خۆت لە خوارەوە دابنێ و جێبەجێی بکە.
-- ئەمە هەژمارەکەت دەکاتە admin.
-- insert into public.workspace_members (workspace_id, user_id, role)
-- select '7d6c5d4e-3f2a-4b1c-9d8e-7f6a5b4c3d2e', id, 'admin'
-- from auth.users where email = 'YOUR_EMAIL_HERE'
-- on conflict (workspace_id, user_id) do update set role = 'admin';

-- بۆ زیادکردنی هاوڕێ بە مۆڵەتی دەستکاریکردن، ئیمەیڵەکەی لە query ـی خوارەوە دابنێ.
-- دڵنیابە هاوڕێکە پێشتر هەژماری دروست کردووە.
-- insert into public.workspace_members (workspace_id, user_id, role)
-- select '7d6c5d4e-3f2a-4b1c-9d8e-7f6a5b4c3d2e', id, 'editor'
-- from auth.users where email = 'FRIEND_EMAIL_HERE'
-- on conflict (workspace_id, user_id) do update set role = 'editor';

-- بۆ بینەر تەنها role بگۆڕە بۆ 'viewer'. بۆ سڕینەوەی مۆڵەت:
-- delete from public.workspace_members
-- where workspace_id = '7d6c5d4e-3f2a-4b1c-9d8e-7f6a5b4c3d2e'
-- and user_id = (select id from auth.users where email = 'FRIEND_EMAIL_HERE');
